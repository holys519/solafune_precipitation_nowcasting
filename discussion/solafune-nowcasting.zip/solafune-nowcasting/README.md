# Solafune Nowcasting — Clean Baseline

**Author:** Modar Ibrahim

A modular U-Net baseline for the Precipitation Nowcasting from Space competition, using Hydra for config and Weights & Biases for experiment tracking.

## Setup

```bash
pip install torch torchvision rasterio hydra-core omegaconf wandb timm scikit-learn
```

**W&B (first time):**
```bash
pip install wandb
wandb login          # authorize
```

## Configure paths

Edit `config/train.yaml` and set your local dataset paths:

```yaml
data:
  train_csv: /path/to/train_dataset/train_dataset.csv
  train_dir: /path/to/train_dataset
```

Set your W&B entity:

```yaml
wandb:
  entity: your-wandb-username
  project: solafune-nowcasting
```

## Train

```bash
# Single run — split-window bands, holdout validation
python train.py bands.combo=split_window data.cv_mode=holdout

# Compare all 5 band combinations
for COMBO in visible ir_classic split_window wv_moisture ice_proxy; do
    python train.py bands.combo=$COMBO data.cv_mode=holdout
done

# K-Fold (5 folds, averages at submission)
python train.py bands.combo=split_window data.cv_mode=kfold

# Try a timm encoder
python train.py model.name=timm_unet model.encoder=resnet18 bands.combo=split_window

# Mixed precision
python train.py training.precision=bf16
```

Results go to `results/<combo>_<model>/`. Best checkpoint: `best.pth` (holdout) or `fold*_best.pth` (kfold).

## Generate submission

```bash
# From a holdout run (single model)
python generate_submission.py \
    --eval_dir /path/to/evaluation_dataset \
    --weights results/split_window_unet/best.pth \
    --bands split_window --model unet \
    --output submission.zip

# From a kfold run (averages all folds)
python generate_submission.py \
    --eval_dir /path/to/evaluation_dataset \
    --results_dir results/split_window_unet \
    --bands split_window --model unet \
    --output submission.zip
```

## File structure

```
├── config/train.yaml          # all hyperparameters
├── models/
│   ├── __init__.py            # model registry
│   ├── unet.py                # scratch U-Net (~1.9M params)
│   └── timm_unet.py           # any timm backbone as encoder
├── dataset.py                 # band combos, normalisation, data loading
├── train.py                   # training loop (Hydra + W&B)
└── generate_submission.py     # inference → submission.zip
```

## Band combinations

| Name | Channels | Notes |
|------|----------|-------|
| `visible` | B1/B2/B3 | Official baseline, daytime only |
| `ir_classic` | 10.4/11.2/12.3µm | All-weather IR |
| `split_window` | BT10.4−BT12.3, 10.4µm, 6.2µm | Best in our experiments |
| `wv_moisture` | 6.2/7.3µm, 10.4µm | Moisture column |
| `ice_proxy` | 3.9µm, 6.2µm, 10.4µm | Glaciated cores |

Add a new combo in `dataset.py`:
```python
BAND_COMBOS["my_combo"] = ("ir_window", "ir_split", "wv_mid")
```
