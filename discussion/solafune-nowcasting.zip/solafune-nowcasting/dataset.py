"""
Data loading for the Solafune Precipitation Nowcasting contest.

Each sample:  3 satellite TIFFs (10-min apart) → 1 GPM-IMERG target (41×41, mm/hr).
Each satellite has 16 spectral bands.  We select 3 physically meaningful bands
and stack them across 3 time frames → 9-channel input.

Band index mappings differ per satellite — see BAND_INDICES below.
"""

import ast
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import rasterio
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset

# Per-satellite 1-based band indices for precipitation-relevant channels.
# Keys match the combo names in BAND_COMBOS below.
# Indices come from physical wavelength matching.
BAND_INDICES: Dict[str, Dict[str, Dict[str, int]]] = {
    "ir_window":  {"himawari": 13, "goes": 13, "meteosat": 14},  # ~10.4 µm
    "ir_window2": {"himawari": 14, "goes": 14, "meteosat": 14},  # ~11.2 µm
    "ir_split":   {"himawari": 15, "goes": 15, "meteosat": 15},  # ~12.3 µm
    "wv_upper":   {"himawari":  8, "goes":  8, "meteosat": 10},  # ~6.2 µm
    "wv_mid":     {"himawari": 10, "goes": 10, "meteosat": 11},  # ~7.3 µm
    "ir_38":      {"himawari":  7, "goes":  7, "meteosat":  9},  # ~3.9 µm
    "vis_blue":   {"himawari":  1, "goes":  1, "meteosat":  1},  # ~0.47 µm
    "vis_green":  {"himawari":  2, "goes":  2, "meteosat":  2},  # ~0.51 µm
    "vis_red":    {"himawari":  3, "goes":  3, "meteosat":  3},  # ~0.64 µm
}

# Each combo lists 3 logical channel names (repeated across 3 time frames = 9 ch).
BAND_COMBOS: Dict[str, Tuple[str, str, str]] = {
    # Official baseline — visible only (daytime only, no night signal)
    "visible": ("vis_blue", "vis_green", "vis_red"),

    # Thermal IR trio — cloud-top brightness temperature, day+night
    # BT10.4 ↔ cloud-top height; BT10.4-BT12.3 ↔ ice water path
    "ir_classic": ("ir_window", "ir_window2", "ir_split"),

    # Best combo from our sweep — pre-computed split-window difference (IWP proxy)
    # + IR window + upper water vapour for deep-convection context
    "split_window": ("ir_window", "ir_split", "wv_upper"),

    # WV moisture column — upper + mid WV + IR; moisture environment of convection
    "wv_moisture": ("wv_upper", "wv_mid", "ir_window"),

    # Mid-IR + WV + IR — ice crystal proxy (3.9 µm) + thermodynamic context
    "ice_proxy": ("ir_38", "wv_upper", "ir_window"),
}

COMBO_DESCRIPTIONS = {
    "visible":        "Visible bands 1-3 (official baseline). Daytime only — near-zero at night.",
    "ir_classic":     "IR trio 10.4/11.2/12.3 µm. Cloud-top BT works day and night.",
    "split_window":   "IR window + split-window + upper WV. Split-window difference = ice water path (best single-model result).",
    "wv_moisture":    "Upper/mid water vapour + IR. Captures the moisture environment feeding convection.",
    "ice_proxy":      "Mid-IR 3.9 µm + WV + IR. 3.9 µm sensitive to ice crystal size (glaciated = heavy rain).",
}


def _parse_filenames(s: str) -> List[str]:
    return ast.literal_eval(s)


def _read_bands(tif_path: Path, band_indices: List[int], target_hw: Tuple[int, int]) -> np.ndarray:
    """Read specific 1-based band indices from a TIFF; resize to target_hw."""
    with rasterio.open(str(tif_path)) as src:
        n_available = src.count
        safe_indices = [min(b, n_available) for b in band_indices]
        data = src.read(safe_indices).astype(np.float32)
    data = data / 255.0
    t = torch.from_numpy(data).unsqueeze(0)
    t = F.interpolate(t, size=target_hw, mode='bilinear', align_corners=False)
    return t.squeeze(0).numpy()


def compute_norm_stats(
    df: pd.DataFrame,
    sat_dirs: Dict[str, Path],
    combo: str,
    target_hw: Tuple[int, int] = (41, 41),
    n_samples: int = 500,
    seed: int = 42,
) -> Dict[int, Tuple[float, float]]:
    """Estimate per-channel (mean, std) from a random sample of training rows."""
    rng = np.random.default_rng(seed)
    sample = df.sample(n=min(n_samples, len(df)), random_state=seed)
    logical_names = BAND_COMBOS[combo]
    accum = [[] for _ in range(len(logical_names))]

    for _, row in sample.iterrows():
        sat = row['satellite_target']
        obs_files = _parse_filenames(row['last_30_minutes_observation_filename'])
        if not obs_files:
            continue
        tif = sat_dirs[sat] / obs_files[-1]
        if not tif.exists():
            continue
        indices = [BAND_INDICES[ch][sat] for ch in logical_names]
        bands = _read_bands(tif, indices, target_hw)
        for c, b in enumerate(bands):
            accum[c].append(b.ravel())

    stats = {}
    for c, vals in enumerate(accum):
        if vals:
            arr = np.concatenate(vals)
            stats[c] = (float(arr.mean()), float(arr.std()) + 1e-6)
        else:
            stats[c] = (0.0, 1.0)
    return stats


class NowcastingDataset(Dataset):
    """
    Loads (9-channel satellite input, 41x41 GPM target) pairs.

    Channels = 3 spectral bands × 3 time frames (t-20min, t-10min, t0).
    Missing frames are zero-padded.  Band selection is driven by `combo`.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        sat_dirs: Dict[str, Path],
        gpm_dir: Optional[Path],
        combo: str,
        norm_stats: Optional[Dict[int, Tuple[float, float]]] = None,
        target_hw: Tuple[int, int] = (41, 41),
        has_target: bool = True,
    ):
        self.df = df.reset_index(drop=True)
        self.sat_dirs = sat_dirs
        self.gpm_dir = gpm_dir
        self.combo = combo
        self.logical_names = BAND_COMBOS[combo]
        self.norm_stats = norm_stats
        self.target_hw = target_hw
        self.has_target = has_target

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        sat = row['satellite_target']
        sat_dir = self.sat_dirs[sat]
        obs_files = _parse_filenames(row['last_30_minutes_observation_filename'])
        band_idx_list = [BAND_INDICES[ch][sat] for ch in self.logical_names]

        channels = []
        for i in range(3):
            if i < len(obs_files):
                tif = sat_dir / obs_files[i]
                if tif.exists():
                    bands = _read_bands(tif, band_idx_list, self.target_hw)
                else:
                    bands = np.zeros((3, *self.target_hw), dtype=np.float32)
            else:
                bands = np.zeros((3, *self.target_hw), dtype=np.float32)
            channels.append(bands)

        x = np.concatenate(channels, axis=0)  # (9, H, W)

        if self.norm_stats:
            for c in range(x.shape[0]):
                if c in self.norm_stats:
                    mean, std = self.norm_stats[c]
                    x[c] = (x[c] - mean) / std

        x_t = torch.from_numpy(x)

        if self.has_target:
            gpm_path = self.gpm_dir / row['gpm_imerg_filename']
            with rasterio.open(str(gpm_path)) as src:
                y = src.read(1).astype(np.float32)[np.newaxis]
                nodata = src.nodata
            if nodata is not None:
                y[y == nodata] = 0.0
            y_t = torch.from_numpy(y)
        else:
            y_t = torch.zeros(1, *self.target_hw)

        meta = {
            'unique_id': row['unique_id'],
            'location': row['name_location'],
            'satellite': sat,
            'gpm_filename': row['gpm_imerg_filename'],
        }
        return x_t, y_t, meta
