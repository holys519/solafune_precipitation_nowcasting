"""
Generate a competition submission zip from trained fold checkpoints.

Averages predictions across all fold models — the standard K-fold inference
approach. Each fold model was trained on different locations, so their average
generalises better than any single fold.

Usage:
    # Average all 5 folds (recommended):
    python generate_submission.py \\
        --weights results/visible_unet/fold1_best.pth results/visible_unet/fold2_best.pth ... \\
        --bands visible --model unet

    # Glob shortcut (all folds in a results dir):
    python generate_submission.py \\
        --results_dir results/visible_unet \\
        --bands visible --model unet

    # Single fold (for quick checks):
    python generate_submission.py \\
        --weights results/visible_unet/fold1_best.pth \\
        --bands visible --model unet

The submission zip contains:
    evaluation_target.csv
    test_files/<gpm_imerg_filename>.tif   (float32, 41x41, mm/hr)
"""

import argparse
import json
import shutil
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
import torch
from omegaconf import OmegaConf
from rasterio.transform import from_bounds
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parent))
from dataset import NowcastingDataset, compute_norm_stats
from models import build_model


def write_tif(arr: np.ndarray, path: Path):
    if arr.ndim == 3:
        arr = arr[0]
    H, W = arr.shape
    path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(str(path), "w", driver="GTiff", height=H, width=W,
                       count=1, dtype=rasterio.float32,
                       crs="EPSG:4326", transform=from_bounds(0, 0, 1, 1, W, H)) as dst:
        dst.write(arr.astype(np.float32), 1)


def run_inference(model, loader, device, loss_type):
    """Run inference with one model; returns (all_preds, all_ids) in raw mm/hr."""
    all_preds, all_ids = [], []
    with torch.no_grad():
        for x, _, meta in loader:
            pred = model(x.to(device)).cpu().float().numpy()
            if loss_type == "log1p":
                pred = np.expm1(pred)
            pred = np.clip(pred, 0, None)
            all_preds.append(pred)
            all_ids.extend(meta["unique_id"])
    return np.concatenate(all_preds), all_ids


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--weights",     nargs="+", default=None, help="One or more .pth paths")
    p.add_argument("--results_dir", default=None, help="Directory with fold*_best.pth files (auto-globs all folds)")
    p.add_argument("--config",      default="config/train.yaml")
    p.add_argument("--bands",       default=None)
    p.add_argument("--model",       default=None)
    p.add_argument("--encoder",     default=None)
    p.add_argument("--output",      default="submission.zip")
    p.add_argument("--batch_size",  type=int, default=64)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--loss",        default="log1p")
    p.add_argument("--eval_dir",    default="/path/to/evaluation_dataset",
                   help="Path to the evaluation dataset directory")
    args = p.parse_args()

    eval_dir = Path(args.eval_dir)
    eval_csv = eval_dir / "evaluation_target.csv"
    sat_dirs = {s: eval_dir / s for s in ["himawari", "goes", "meteosat"]}

    # Resolve weight paths
    if args.results_dir:
        weight_paths = sorted(Path(args.results_dir).glob("fold*_best.pth"))
        if not weight_paths:
            raise FileNotFoundError(f"No fold*_best.pth files in {args.results_dir}")
    elif args.weights:
        weight_paths = [Path(w) for w in args.weights]
    else:
        raise ValueError("Provide --weights or --results_dir")

    print(f"Averaging {len(weight_paths)} fold model(s):")
    for w in weight_paths:
        print(f"  {w}")

    cfg = OmegaConf.load(args.config)
    if args.bands:   cfg.bands.combo   = args.bands
    if args.model:   cfg.model.name    = args.model
    if args.encoder: cfg.model.encoder = args.encoder

    combo  = cfg.bands.combo
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nDevice: {device}  combo: {combo}  model: {cfg.model.name}  loss: {args.loss}")

    # Norm stats
    stats_path = weight_paths[0].parent / "norm_stats.json"
    if stats_path.exists():
        norm_stats = {int(k): tuple(v) for k, v in json.load(open(stats_path)).items()}
        print(f"Loaded norm stats from {stats_path}")
    else:
        train_dir  = Path(cfg.data.train_dir)
        train_sats = {s: train_dir / s for s in ["himawari", "goes", "meteosat"]}
        df_tr      = pd.read_csv(cfg.data.train_csv)
        print("Computing norm stats from training data …")
        norm_stats = compute_norm_stats(df_tr, train_sats, combo,
                                        n_samples=cfg.data.norm_samples,
                                        seed=cfg.training.seed)

    eval_df = pd.read_csv(eval_csv)
    print(f"Eval rows: {len(eval_df):,}")
    ds = NowcastingDataset(eval_df, sat_dirs, gpm_dir=None, combo=combo,
                           norm_stats=norm_stats, has_target=False)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=False,
                        num_workers=args.num_workers, pin_memory=device.type == "cuda")

    # Run inference for each fold and accumulate (online mean to save memory)
    sum_preds = None
    all_ids   = None

    for i, wpath in enumerate(weight_paths):
        model = build_model(cfg.model).to(device)
        state = torch.load(str(wpath), map_location=device)
        if isinstance(state, dict) and "state_dict" in state:
            state = state["state_dict"]
        model.load_state_dict(state)
        model.eval()
        print(f"\n[{i+1}/{len(weight_paths)}] {wpath.name}  ({model.count_params():,} params)")

        preds, ids = run_inference(model, loader, device, args.loss)
        print(f"  mean={preds.mean():.4f}  max={preds.max():.4f}  >0.01: {(preds>0.01).mean()*100:.1f}%")

        if sum_preds is None:
            sum_preds = preds.astype(np.float64)
            all_ids   = ids
        else:
            assert ids == all_ids, "Fold models returned different sample ordering"
            sum_preds += preds

        del model

    avg_preds = (sum_preds / len(weight_paths)).astype(np.float32)
    print(f"\nEnsemble average — mean={avg_preds.mean():.4f}  max={avg_preds.max():.4f}  "
          f">0.01: {(avg_preds>0.01).mean()*100:.1f}%")

    uid_to_row = {row["unique_id"]: row for _, row in eval_df.iterrows()}
    tmp_dir = Path("_tmp_submission")
    tmp_dir.mkdir(exist_ok=True)

    written = []
    for uid, pred in zip(all_ids, avg_preds):
        row      = uid_to_row[uid]
        out_name = row["gpm_imerg_filename"]
        out_path = tmp_dir / out_name
        write_tif(pred, out_path)
        written.append((out_path, out_name))

    csv_path = tmp_dir / "evaluation_target.csv"
    pd.DataFrame({
        "unique_id":          all_ids,
        "gpm_imerg_filename": [uid_to_row[u]["gpm_imerg_filename"] for u in all_ids],
    }).to_csv(csv_path, index=False)

    out_zip = Path(args.output)
    with zipfile.ZipFile(str(out_zip), "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(csv_path, arcname="evaluation_target.csv")
        for fpath, fname in written:
            zf.write(fpath, arcname=f"test_files/{fname}")

    shutil.rmtree(tmp_dir)
    print(f"\nSubmission saved: {out_zip}  ({out_zip.stat().st_size/1e6:.1f} MB)")
    print(f"Contains: {len(written)} TIFFs + evaluation_target.csv  "
          f"({'fold average' if len(weight_paths) > 1 else 'single fold'})")


if __name__ == "__main__":
    main()
