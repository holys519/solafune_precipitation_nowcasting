"""
Model registry. Add a new architecture by decorating it with @register.

Usage in train.py:
    from models import build_model
    model = build_model(cfg.model)
"""

from __future__ import annotations
from typing import Callable, Dict
from omegaconf import DictConfig

_REGISTRY: Dict[str, Callable] = {}


def register(name: str):
    def decorator(cls):
        _REGISTRY[name] = cls
        return cls
    return decorator


def build_model(model_cfg: DictConfig):
    name = model_cfg.name
    if name not in _REGISTRY:
        raise ValueError(f"Unknown model '{name}'. Available: {list(_REGISTRY)}")
    return _REGISTRY[name](model_cfg)


# Side-effect imports so decorators run and populate the registry
from models.unet import SmallUNet          # noqa: F401, E402
from models.timm_unet import TimmUNet      # noqa: F401, E402
