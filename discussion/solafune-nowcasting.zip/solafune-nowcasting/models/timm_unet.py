"""
timm-encoder U-Net — use any timm CNN as the encoder backbone.
The decoder is a lightweight transposed-conv decoder matching encoder features.

Config keys used:
    model.name: timm_unet
    model.encoder: resnet18        # any timm model with feature_info
    model.pretrained: false        # true to load ImageNet weights
    model.in_ch: 9                 # 9-channel satellite input
    model.decoder_ch: 128          # decoder channel width

Popular lightweight encoders to try:
    resnet18, resnet34, efficientnet_b0, mobilenetv3_small_100,
    convnext_tiny, tf_efficientnetv2_s
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
from omegaconf import DictConfig
from models import register


class _DecoderBlock(nn.Module):
    def __init__(self, in_ch, skip_ch, out_ch):
        super().__init__()
        self.up   = nn.ConvTranspose2d(in_ch, out_ch, 2, stride=2)
        self.conv = nn.Sequential(
            nn.Conv2d(out_ch + skip_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x, skip):
        x = self.up(x)
        if x.shape != skip.shape:
            x = F.interpolate(x, size=skip.shape[-2:], mode='bilinear', align_corners=False)
        return self.conv(torch.cat([x, skip], 1))


@register("timm_unet")
class TimmUNet(nn.Module):
    """
    U-Net with a timm encoder backbone.
    First conv is replaced to accept `in_ch` satellite channels instead of RGB.
    """

    def __init__(self, cfg: DictConfig):
        super().__init__()
        encoder_name = cfg.get("encoder", "resnet18")
        pretrained   = cfg.get("pretrained", False)
        in_ch        = cfg.get("in_ch", 9)
        dec_ch       = cfg.get("decoder_ch", 128)

        self.encoder = timm.create_model(
            encoder_name,
            pretrained=pretrained,
            features_only=True,
            in_chans=in_ch,
        )
        enc_channels = [info["num_chs"] for info in self.encoder.feature_info]

        # Build decoder — pairs each encoder level with a skip connection
        self.decoders = nn.ModuleList()
        prev_ch = enc_channels[-1]
        for skip_ch in reversed(enc_channels[:-1]):
            out = max(dec_ch, skip_ch // 2)
            self.decoders.append(_DecoderBlock(prev_ch, skip_ch, out))
            prev_ch = out

        self.head = nn.Conv2d(prev_ch, 1, 1)

    def forward(self, x):
        input_hw = x.shape[-2:]
        feats = self.encoder(x)
        d = feats[-1]
        skips = list(reversed(feats[:-1]))
        for dec, skip in zip(self.decoders, skips):
            d = dec(d, skip)
        # Upsample to original input size (handles any encoder stride)
        d = F.interpolate(d, size=input_hw, mode='bilinear', align_corners=False)
        return self.head(d)

    def count_params(self):
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
