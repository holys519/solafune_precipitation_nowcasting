"""
Small custom U-Net — no external pretrained weights, fully from scratch.
~190K params at base_ch=32.  Fast to train, easy to understand.

Config keys used:
    model.name: unet
    model.in_ch: 9          # 3 bands × 3 frames
    model.base_ch: 32       # scale up for more capacity
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from omegaconf import DictConfig
from models import register


class _ConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


@register("unet")
class SmallUNet(nn.Module):
    """3-level U-Net encoder-decoder with skip connections."""

    def __init__(self, cfg: DictConfig):
        super().__init__()
        in_ch  = cfg.get("in_ch", 9)
        b      = cfg.get("base_ch", 32)

        self.enc1 = _ConvBlock(in_ch, b)
        self.enc2 = _ConvBlock(b, b * 2)
        self.enc3 = _ConvBlock(b * 2, b * 4)
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = _ConvBlock(b * 4, b * 8)

        self.up3  = nn.ConvTranspose2d(b * 8, b * 4, 2, stride=2)
        self.dec3 = _ConvBlock(b * 8, b * 4)
        self.up2  = nn.ConvTranspose2d(b * 4, b * 2, 2, stride=2)
        self.dec2 = _ConvBlock(b * 4, b * 2)
        self.up1  = nn.ConvTranspose2d(b * 2, b, 2, stride=2)
        self.dec1 = _ConvBlock(b * 2, b)
        self.head = nn.Conv2d(b, 1, 1)

    def forward(self, x):
        x, pad = _pad8(x)
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        bn = self.bottleneck(self.pool(e3))
        d3 = self.dec3(torch.cat([self.up3(bn), e3], 1))
        d2 = self.dec2(torch.cat([self.up2(d3), e2], 1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], 1))
        return _unpad8(self.head(d1), pad)

    def count_params(self):
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def _pad8(x):
    # Pad spatial dims to next multiple of 8 (required for 3 pooling levels)
    h, w = x.shape[-2:]
    ph = (8 - h % 8) % 8
    pw = (8 - w % 8) % 8
    if ph or pw:
        x = F.pad(x, (0, pw, 0, ph))
    return x, (ph, pw)


def _unpad8(x, pad):
    ph, pw = pad
    if ph: x = x[..., :-ph, :]
    if pw: x = x[..., :-pw]
    return x
