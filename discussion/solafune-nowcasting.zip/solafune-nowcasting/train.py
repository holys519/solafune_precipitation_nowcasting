"""
Train a nowcasting model with K-fold cross-validation.

Usage:
    python train.py                                  # default config
    python train.py bands.combo=ir_classic           # override one key
    python train.py model.name=timm_unet model.encoder=resnet18
    python train.py training.precision=bf16
    python train.py bands.combo=split_window training.loss=mse

Hydra writes run outputs to outputs/<date>/<time>/.
Results (fold scores, best weights) go to paths.output_dir.
"""

import logging
import os
import sys
from pathlib import Path

import hydra
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from omegaconf import DictConfig, OmegaConf
from torch.utils.data import DataLoader
from sklearn.model_selection import GroupKFold

import wandb

sys.path.insert(0, str(Path(__file__).resolve().parent))

from dataset import NowcastingDataset, BAND_COMBOS, COMBO_DESCRIPTIONS, compute_norm_stats
from models import build_model

log = logging.getLogger(__name__)


def rmse(preds: np.ndarray, targets: np.ndarray) -> float:
    return float(np.sqrt(np.mean((preds - targets) ** 2)))


def get_autocast(precision: str, device: torch.device):
    if precision == "fp16" and device.type == "cuda":
        return torch.cuda.amp.autocast(dtype=torch.float16)
    if precision == "bf16" and device.type == "cuda":
        return torch.cuda.amp.autocast(dtype=torch.bfloat16)
    return torch.amp.autocast(device_type=device.type, enabled=False)


def run_epoch(model, loader, criterion, optimizer, device, scaler,
              precision, loss_type, training, wandb_run, log_interval, epoch):
    model.train(training)
    total_loss = 0.0
    all_preds, all_targets = [], []
    ctx = get_autocast(precision, device)

    for step, (x, y, _) in enumerate(loader):
        x, y = x.to(device), y.to(device)

        with ctx:
            pred = model(x)
            if loss_type == "log1p":
                loss = criterion(pred, torch.log1p(y))
            else:
                loss = criterion(pred, y)

        if training:
            optimizer.zero_grad()
            if scaler:
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
            else:
                loss.backward()
                optimizer.step()

        with torch.no_grad():
            pred_raw = torch.expm1(pred).clamp(0) if loss_type == "log1p" else pred
            pred_raw = pred_raw.clamp(0)
            all_preds.append(pred_raw.cpu().float().numpy())
            all_targets.append(y.cpu().float().numpy())

        total_loss += loss.item()

        if training and wandb_run and (step + 1) % log_interval == 0:
            wandb_run.log({"batch_loss": loss.item(), "epoch": epoch})

    all_preds   = np.concatenate(all_preds)
    all_targets = np.concatenate(all_targets)
    return total_loss / len(loader), rmse(all_preds, all_targets)


def train_fold(cfg: DictConfig, fold_idx: int, train_df: pd.DataFrame,
               val_df: pd.DataFrame, sat_dirs: dict, gpm_dir: Path,
               device: torch.device, wandb_run, cv_mode: str = "kfold") -> dict:

    combo   = cfg.bands.combo
    loss_type = cfg.training.loss
    precision = cfg.training.precision

    log.info(f"  Computing norm stats from {cfg.data.norm_samples} train samples …")
    norm_stats = compute_norm_stats(
        train_df, sat_dirs, combo,
        target_hw=tuple(cfg.data.target_size),
        n_samples=cfg.data.norm_samples,
        seed=cfg.training.seed,
    )

    hw = tuple(cfg.data.target_size)
    train_ds = NowcastingDataset(train_df, sat_dirs, gpm_dir, combo, norm_stats, hw)
    val_ds   = NowcastingDataset(val_df,   sat_dirs, gpm_dir, combo, norm_stats, hw)

    train_loader = DataLoader(train_ds, batch_size=cfg.training.batch_size,
                              shuffle=True,  num_workers=cfg.training.num_workers,
                              pin_memory=device.type == "cuda")
    val_loader   = DataLoader(val_ds,   batch_size=cfg.training.batch_size * 2,
                              shuffle=False, num_workers=cfg.training.num_workers,
                              pin_memory=device.type == "cuda")

    model = build_model(cfg.model).to(device)
    if fold_idx == 0:
        log.info(f"  Model: {cfg.model.name}  params={model.count_params():,}")

    optimizer = torch.optim.Adam(model.parameters(),
                                 lr=cfg.training.lr,
                                 weight_decay=cfg.training.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=3)
    criterion = nn.MSELoss()
    scaler    = torch.cuda.amp.GradScaler() if precision == "fp16" else None

    best_val_rmse = float("inf")
    best_epoch    = 0
    patience_ctr  = 0
    best_state    = None

    for epoch in range(1, cfg.training.epochs + 1):
        tr_loss, tr_rmse = run_epoch(model, train_loader, criterion, optimizer,
                                     device, scaler, precision, loss_type,
                                     True, wandb_run, cfg.wandb.log_interval, epoch)
        _, val_rmse = run_epoch(model, val_loader, criterion, None,
                                device, scaler, precision, loss_type,
                                False, wandb_run, cfg.wandb.log_interval, epoch)
        scheduler.step(val_rmse)

        log.info(f"  Fold {fold_idx+1} Epoch {epoch:2d} | "
                 f"train_loss={tr_loss:.4f} tr_rmse={tr_rmse:.4f} "
                 f"val_rmse={val_rmse:.4f}")

        if wandb_run:
            # Holdout: flat names so all band combos overlay on the same wandb chart.
            # KFold: prefix per fold to track each split separately.
            prefix = "" if cv_mode == "holdout" else f"fold{fold_idx+1}/"
            wandb_run.log({
                f"{prefix}train_loss": tr_loss,
                f"{prefix}train_rmse": tr_rmse,
                f"{prefix}val_rmse":   val_rmse,
                f"{prefix}lr":         optimizer.param_groups[0]["lr"],
                "epoch": epoch,
            })

        if val_rmse < best_val_rmse:
            best_val_rmse = val_rmse
            best_epoch    = epoch
            patience_ctr  = 0
            best_state    = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        else:
            patience_ctr += 1
            if patience_ctr >= cfg.training.patience:
                log.info(f"  Early stop at epoch {epoch} (best={best_val_rmse:.4f} @ ep{best_epoch})")
                break

    return {"fold": fold_idx + 1, "best_val_rmse": best_val_rmse,
            "best_epoch": best_epoch, "state_dict": best_state}


@hydra.main(config_path="config", config_name="train", version_base=None)
def main(cfg: DictConfig):
    torch.manual_seed(cfg.training.seed)
    np.random.seed(cfg.training.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    log.info(f"Device: {device}  |  combo: {cfg.bands.combo}  |  model: {cfg.model.name}")
    log.info(f"  {COMBO_DESCRIPTIONS.get(cfg.bands.combo, '')}")

    train_dir = Path(cfg.data.train_dir)
    df = pd.read_csv(cfg.data.train_csv)
    sat_dirs = {
        "himawari": train_dir / "himawari",
        "goes":     train_dir / "goes",
        "meteosat": train_dir / "meteosat",
    }
    gpm_dir = train_dir / "gpm_imerg"

    import json
    locations  = df["name_location"].values
    cv_mode    = cfg.data.get("cv_mode", "kfold")

    combo_short = {
        "visible":        "vis  [B1-B3]",
        "ir_classic":     "IR classic [10.4/11.2/12.3µm]",
        "split_window":   "split-window [SW-diff+IR+WV]",
        "wv_moisture":    "WV moisture [6.2/7.3µm+IR]",
        "ice_proxy":      "ice proxy [3.9µm+WV+IR]",
    }.get(cfg.bands.combo, cfg.bands.combo)
    run_name = combo_short
    wandb_run = wandb.init(
        entity=cfg.wandb.entity,
        project=cfg.wandb.project,
        name=run_name,
        config=OmegaConf.to_container(cfg, resolve=True),
        reinit=True,
    )

    out_dir = Path(cfg.paths.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if cv_mode == "holdout":
        holdout_locs = list(cfg.data.holdout_locations)
        va_mask = np.isin(locations, holdout_locs)
        splits = [(np.where(~va_mask)[0], np.where(va_mask)[0])]
        log.info(f"Holdout mode — val locations: {holdout_locs}")
    else:
        gkf    = GroupKFold(n_splits=cfg.data.n_folds)
        splits = list(gkf.split(df, groups=locations))
        log.info(f"K-Fold mode — {cfg.data.n_folds} folds")

    fold_results = []
    for fold_idx, (tr_idx, va_idx) in enumerate(splits):
        log.info(f"\nFold {fold_idx+1}/{len(splits)} "
                 f"— val locations: {sorted(set(locations[va_idx]))}")
        res = train_fold(cfg, fold_idx, df.iloc[tr_idx], df.iloc[va_idx],
                         sat_dirs, gpm_dir, device, wandb_run, cv_mode)
        fold_results.append(res)

        ckpt_name = "best.pth" if cv_mode == "holdout" else f"fold{fold_idx+1}_best.pth"
        ckpt_path = out_dir / ckpt_name
        torch.save(res["state_dict"], ckpt_path)
        log.info(f"  Saved → {ckpt_path}")

    val_rmses = [r["best_val_rmse"] for r in fold_results]
    mean_rmse = float(np.mean(val_rmses))
    std_rmse  = float(np.std(val_rmses))

    log.info(f"\n{'='*50}")
    log.info(f"{cv_mode} summary  combo={cfg.bands.combo}  model={cfg.model.name}")
    for r in fold_results:
        log.info(f"  Fold {r['fold']}: val_rmse={r['best_val_rmse']:.4f}  best_ep={r['best_epoch']}")
    log.info(f"  Mean ± Std : {mean_rmse:.4f} ± {std_rmse:.4f}")

    summary = {
        "combo":        cfg.bands.combo,
        "model":        cfg.model.name,
        "loss":         cfg.training.loss,
        "precision":    cfg.training.precision,
        "cv_mode":      cv_mode,
        "mean_cv_rmse": mean_rmse,
        "std_cv_rmse":  std_rmse,
        "fold_rmses":   val_rmses,
    }

    results_file = out_dir / "cv_results.json"
    with open(results_file, "w") as f:
        json.dump(summary, f, indent=2)
    log.info(f"Results saved → {results_file}")

    if wandb_run:
        wandb_run.summary["mean_cv_rmse"] = mean_rmse
        wandb_run.summary["std_cv_rmse"]  = std_rmse
        for i, r in enumerate(fold_results):
            wandb_run.summary[f"fold{i+1}_val_rmse"] = r["best_val_rmse"]
        wandb_run.finish()


if __name__ == "__main__":
    main()
